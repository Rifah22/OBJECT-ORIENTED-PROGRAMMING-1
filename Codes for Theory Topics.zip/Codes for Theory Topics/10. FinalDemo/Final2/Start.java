import java.lang.*;

public class Start
{
	public static void main(String args[])
	{
		FinalMethodDemo fmd = new FinalMethodDemo();
		fmd.show();
		Child c = new Child();
		c.show();
	}
}