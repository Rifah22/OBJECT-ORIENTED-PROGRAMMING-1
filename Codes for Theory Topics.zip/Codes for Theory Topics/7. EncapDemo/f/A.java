package f;

import java.lang.*;

public class A
{
	private int a1;
	public int a2;
	protected int a3;
	int a4;
	
	public void show()
	{
		System.out.println(a1 + " " + a2 + " " + a3 + " " +a4);
	}
}