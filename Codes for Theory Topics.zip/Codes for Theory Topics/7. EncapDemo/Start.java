import java.lang.*;
import f.*;

public class Start
{
	public static void main(String []args)
	{
		A a = new A();
		
		//a.a1 = 10;
		a.a2 = 20;
		//a.a3 = 30;
		//a.a4 = 40;
		
		a.show();
	}
}