import java.lang.*;

public class Start
{
	public static void main(String args[])
	{
		Account acc = new Account(1111,"RM",500);
		acc.showDetails();
		
	}
}