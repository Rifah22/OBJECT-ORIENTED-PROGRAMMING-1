package a.bc.d;
public class D{
	public void showD(){System.out.println("aa");}
}