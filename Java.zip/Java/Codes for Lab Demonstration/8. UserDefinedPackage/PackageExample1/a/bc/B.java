package a.bc;
import a.bc.d.D;
public class B{
	D d = new D();
	public B(){d.showD();}
}