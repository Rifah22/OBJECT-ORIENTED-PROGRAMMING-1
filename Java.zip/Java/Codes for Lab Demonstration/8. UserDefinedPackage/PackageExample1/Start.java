import a.A;
import a.bc.*;
import a.bc.d.D;

public class Start{
	public static void main(String []args){
		A a= new A();
		B b= new B();
		C c= new C();
		D d= new D();
	}
}
