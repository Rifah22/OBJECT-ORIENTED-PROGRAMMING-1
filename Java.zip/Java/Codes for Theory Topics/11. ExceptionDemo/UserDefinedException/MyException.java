import java.lang.*;

public class MyException extends Exception
{
	public MyException(String s){
		super(s);
	}
	//public String getMessage(){return "Invalid User";}
}