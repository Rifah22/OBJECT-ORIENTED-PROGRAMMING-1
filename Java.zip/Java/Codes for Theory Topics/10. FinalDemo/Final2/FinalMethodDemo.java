import java.lang.*;

public class FinalMethodDemo
{
	public final void show()
	{
		System.out.println("This is Final");
	}
}