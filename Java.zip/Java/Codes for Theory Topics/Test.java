import java.util.Scanner;
public class Test{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		if(sc.hasNextInt()){
			System.out.println(sc.nextInt());
		}
	}
}